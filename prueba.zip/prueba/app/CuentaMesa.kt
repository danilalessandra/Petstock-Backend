class CuentaMesa(val nombre: String) {
    val items = mutableListOf<ItemMesa>()
    var aceptaPropina: Boolean = true

    fun agregarItem(itemMenu: ItemMenu, cantidad: Int) {
        // Verificar si el ítem ya existe en la lista, en cuyo caso solo actualizamos la cantidad
        val existingItem = items.find { it.itemMenu == itemMenu }
        if (existingItem != null) {
            existingItem.cantidad += cantidad
        } else {
            val newItem = ItemMesa(itemMenu, cantidad)
            items.add(newItem)
        }
    }

    fun calcularTotalSinPropina(): Int {
        var total = 0
        for (item in items) {
            total += item.calcularSubtotal()
        }
        return total
    }

    fun calcularPropina(): Int {
        return if (aceptaPropina) (calcularTotalSinPropina() * 0.1).toInt() else 0
    }

    fun calcularTotalConPropina(): Int {
        return calcularTotalSinPropina() + calcularPropina()
    }
}
