class ItemMenu(val nombre: String, val precio: Int)
