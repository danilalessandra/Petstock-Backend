package com.example.prueba

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var cuentaMesa: CuentaMesa
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("es", "CL"))

    private lateinit var editTextCantidadPastelDeChoclo: EditText
    private lateinit var editTextCantidadCazuela: EditText
    private lateinit var switchPropina: Switch
    private lateinit var textViewTotalSinPropina: TextView
    private lateinit var textViewPropina: TextView
    private lateinit var textViewTotalConPropina: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializar la cuenta de la mesa y mostrar los precios en la interfaz
        cuentaMesa = CuentaMesa("Mesa 1")
        actualizarPrecios()

        // Obtener referencias a las vistas utilizando los IDs correspondientes
        editTextCantidadPastelDeChoclo = findViewById(R.id.editTextTextMultiLine3)
        editTextCantidadCazuela = findViewById(R.id.editTextTextMultiLine4)
        switchPropina = findViewById(R.id.switch3)
        textViewTotalSinPropina = findViewById(R.id.textViewTotalSinPropina)
        textViewPropina = findViewById(R.id.textViewPropina)
        textViewTotalConPropina = findViewById(R.id.textViewTotalConPropina)

        // Agregar listener para el cambio de cantidad de Pastel de Choclo
        editTextCantidadPastelDeChoclo.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                actualizarPrecios()
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        // Agregar listener para el cambio de cantidad de Cazuela
        editTextCantidadCazuela.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                actualizarPrecios()
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        // Agregar listener para el cambio de propina
        switchPropina.setOnCheckedChangeListener { _, isChecked ->
            cuentaMesa.aceptaPropina = isChecked
            actualizarPrecios()
        }
    }

    private fun actualizarPrecios() {
        // Obtener la cantidad ingresada para Pastel de Choclo
        val cantidadPastelDeChoclo = editTextCantidadPastelDeChoclo.text.toString().toIntOrNull() ?: 0

        // Obtener la cantidad ingresada para Cazuela
        val cantidadCazuela = editTextCantidadCazuela.text.toString().toIntOrNull() ?: 0

        // Limpiar la lista de ítems para evitar duplicaciones
        cuentaMesa.items.clear()

        // Agregar los ítems a la cuenta de la mesa
        cuentaMesa.agregarItem(ItemMenu("Pastel de Choclo", 12000), cantidadPastelDeChoclo)
        cuentaMesa.agregarItem(ItemMenu("Cazuela", 10000), cantidadCazuela)

        // Calcular los totales
        val totalSinPropina = cuentaMesa.calcularTotalSinPropina()
        val propina = cuentaMesa.calcularPropina()
        val totalConPropina = cuentaMesa.calcularTotalConPropina()

        // Formatear los valores monetarios como pesos chilenos
        val totalSinPropinaFormatted = currencyFormat.format(totalSinPropina)
        val propinaFormatted = currencyFormat.format(propina)
        val totalConPropinaFormatted = currencyFormat.format(totalConPropina)

        // Mostrar los totales en la interfaz
        textViewTotalSinPropina.text = "Total sin propina: $totalSinPropinaFormatted"
        textViewPropina.text = "Propina: $propinaFormatted"
        textViewTotalConPropina.text = "Total con propina: $totalConPropinaFormatted"
    }
}
